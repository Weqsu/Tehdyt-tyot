<?php
/*
    file:   Lopputyö/src/logout.php
    desc:   Hävittää session-tiedot, jolloin kirjautuminen loppuu
    date:	11.05.2020
*/
session_start();
session_destroy();
header('location:index.php?sivu=viesti&viesti=Olet kirjautunut ulos!&virhe=false');
?>