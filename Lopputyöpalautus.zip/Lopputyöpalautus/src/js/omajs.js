$(document).ready(function(){
	$("#goback").click(function(){
		window.history.back();
	});
	$("#goback2").click(function(){
		window.history.go(-2);
	});
});