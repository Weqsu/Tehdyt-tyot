<?php
/*
    file:   Lopputyö/src/admin/resurssit.php
    desc:   Näyttää varattavat resurssit
    date:	16.05.2020
*/

echo '<p><a class="btn btn-primary" href="index.php?sivu=uusiResurssi">Uusi resurssi</a> <a class="btn btn-primary" href="index.php?sivu=poistaResurssi">Poista resurssi</a></p>';
echo '<div class="row">';
include('dbConnect.php'); //otetaan käyttöön tietokantayhteysobjekti $conn
$sql="SELECT resurssiID, nimi, kuvaus, paikka, huomautus FROM resurssi";
$tulos=$conn->query($sql); //suoritetaan SQL-lause ja luodaan $tulos-niminen "joukko"
if($tulos->num_rows > 0){
    //tulostetaan löytyneet rivit
       while($rivi=$tulos->fetch_assoc()){
        echo '<div class="col-sm-6">';
        echo '<div class="card card border-primary"><div class="card-header text-center"><p><b>Nimi:</b><br>'.$rivi['nimi'].'</p>';echo'</div>';
        echo '<div class="card-body text-center"><p><b>Kuvaus:<br></b>'.$rivi['kuvaus'];
        echo '<p><b>Paikka:<br></b>'.$rivi['paikka'];
        echo'</div>';
           echo '<br>';
        echo '<div class="card-footer text-center"><p><b>Huomautus:</b><br>'.$rivi['huomautus'];
        
        echo '</p></div></div>';
        echo '<p></p>';
        echo '</div>';
    }
    echo '</div>'; //loppuu div class="card-columns"
}else echo '<p class="alert alert-danger">Ei löytynyt tietoja</p>';
$conn->close(); //suljetaan tietokantayhteys
?>
