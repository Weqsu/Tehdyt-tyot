<?php
/*
	file:	Lopputyö/src/admin/login.php
	desc:	Tarkistaa kirjautumisen tietokannasta, lisää kirjautumistiedot session-muuttujille
	date:	16.05.2020
*/
if(!empty($_POST)){
    
	//tultiin lomakkeelta
	$email=$_POST['email'];
	$salasana=$_POST['salasana'];
	include('dbConnect.php');  
    //ylemmässä kansiossa oleva tietokantayhteys
	$sql="SELECT adminID,email,salasana,etunimi,sukunimi FROM admin WHERE email='$email'";
	$tulos=$conn->query($sql);
	if($tulos->num_rows > 0){
		//löytyi email
		$ksala=$conn->real_escape_string($salasana);
		$rivi=$tulos->fetch_assoc();
		if(password_verify($ksala,$rivi['salasana'])){
			//kirjautuminen ok
			session_start();
			$_SESSION['userID']=$rivi['adminID'];
			$_SESSION['nimi']=$rivi['etunimi'].' '.$rivi['sukunimi'];
			$_SESSION['aika']=date('H:i:s');
			header('location:index.php');
		}else header('location:kirjaudu.php?virhe=salasana');
	}else header('location:kirjaudu.php?virhe=email');
}else header('location:kirjaudu.php?virhe=kirjaudu');
?>