<?php
/*
	file:	Lopputyö/src/admin/poistaVaraus.php
	desc:	Poistaa valitun varauksen tietokannasta
	date:	18.05.2020
*/ 
$varausID=$_GET['varausID'];
include('dbConnect.php');
$sql="DELETE FROM varaus WHERE varausID=$varausID";
if($conn->query($sql) === TRUE) {
	//jos DELETE-lause onnistui, tieto päivittyi tietokantaan
	$conn->close();
	header('location:index.php?sivu=varaukset&virhe=false&viesti=Varauksen poisto onnistui');
}else{
	$conn->close();
	header('location:index.php?sivu=varaukset&virhe=true&viesti=Poisto ei onnistu!');
}
?>