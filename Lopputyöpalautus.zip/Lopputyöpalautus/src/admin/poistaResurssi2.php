<?php
/*
	file:	Lopputyö/src/admin/poistaResurssi2.php
	desc:	Poistaa valitun resurssin tietokannasta
	date:	18.05.2020
*/
$resurssiID=$_GET['resurssiID'];
include('dbConnect.php');
$sql="DELETE FROM resurssi WHERE resurssiID=$resurssiID";
if($conn->query($sql) === TRUE) {
	//jos DELETE-lause onnistui, tieto päivittyi tietokantaan
	$conn->close();
	header('location:index.php?sivu=resurssit&virhe=false&viesti=Resurssin poisto onnistui');
}else{
	$conn->close();
	header('location:index.php?sivu=resurssit&virhe=true&viesti=Poisto ei onnistu!');
}
?>