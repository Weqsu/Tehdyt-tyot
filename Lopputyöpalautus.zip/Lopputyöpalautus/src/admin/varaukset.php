<?php
/*
	file:	Lopputyö/src/admin/varaukset.php
	desc:	Näyttää varaukset jasenID:n avulla
	date:	16.05.2020
*/
echo '<a class="btn btn-primary" href="index.php?sivu=muokkaaVaraus">Poista varauksia</a></p>';
include('dbConnect.php');
$sql="SELECT varausID, varausAika,lopetusAika,sukunimi,etunimi,email, nimi 
        FROM varaus 
        INNER JOIN kayttajat 
        ON varaus.jasenID=kayttajat.jasenID 
        INNER JOIN resurssi 
        ON varaus.resurssiID=resurssi.resurssiID 
        WHERE now() < lopetusAika ";
$tulos=$conn->query($sql);
 echo '<div class="row">';
    $laskuri=0;
    while($rivi=$tulos->fetch_assoc()){
        $alkuaika=date_create($rivi['varausAika']);  //muokataan päivämäärän esitysmuotoa ja sen vuoksi
        $loppuaika=date_create($rivi['lopetusAika']);//alku- ja loppuaika poimitaan muuttujille tietokantariviltä
        echo '<div class="col-sm-6">';
        echo '<div class="card"><div class="card-header text-center"><p>Varaus ajalle:<br><b>';
		//tulostetaan alku- ja loppuaika erikseen eli pvm muotoiltuna ja klo muotoiltuna
        echo date_format($alkuaika,'d.m.Y').', klo '.date_format($alkuaika,'H:i').' - ';
        echo date_format($loppuaika,'d.m.Y').', klo '.date_format($loppuaika,'H:i').'</b></p></div>';
        echo '<div class="card-body bg-success text-center">'.$rivi['nimi'].'</div>';
        echo '<div class="card-footer text-center"><p>Varaaja:<br><b>'.$rivi['etunimi'].' '.$rivi['sukunimi'];
        echo '</b><br>'.$rivi['email'];
        echo '</p></div></div>';
        echo '<p></p>';
        echo '</div>';
        
        $laskuri++;
        
} echo '</div>';

$conn->close();
?>