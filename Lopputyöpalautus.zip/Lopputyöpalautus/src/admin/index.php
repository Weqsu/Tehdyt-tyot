<?php
/*
	file:	Lopputyö/src/admin/index.php
	desc:	Ylläpitopuolen oletussivu. Näkyy vain kirjautuneelle käyttäjälle. Ei talletu välimuisteihin.
	date:	15.05.2020
*/
session_start();
if(!isset($_SESSION['userID'])) header('location:kirjaudu.php'); //vaatii kirjautumisen!
if(!empty($_GET['sivu'])) $sivu=$_GET['sivu'];else $sivu='';
header('Cache-control:no-cache,no-store,must-revalidate');
?>
<!DOCTYPE html>
<html>
<head>
 <title>Tilojen varaaminen</title>
 <meta charset="utf-8"> <!-- Luodaan bootsrap linkit + css linkit-->
 <meta name="viewport" content="width=device-width, initial-scale=1">   
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
 <link href="../css/style.css" rel="stylesheet">
</head>
	<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">    
    <div class="container-fluid">
        <div class="navbar-header">
  <!-- Luodaan LapinAmk:n logo navigointi palkkiin-->
      <a class="navbar-brand" href="index.php"><img src="../images/uus1.png" class="img-responsive"></a>
        </div>
        
        <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
            <!--Etusivun linkit-->
        <li class=header <?php if($sivu=='') echo 'class="active"';?>><a href="index.php">Etusivu</a></li>
          
        <li <?php if($sivu=='adminit') echo 'class="active"';?>><a href="index.php?sivu=adminit">Ylläpitäjät</a></li>
          
        <li <?php if($sivu=='varaukset') echo 'class="active"';?>><a href="index.php?sivu=varaukset">Varaukset</a></li>
        <li <?php if($sivu=='kayttajat' OR $sivu=='talletaVaraus') echo 'class="active"';?>><a href="index.php?sivu=kayttajat">Muut Käyttäjät</a></li>
            <li <?php if($sivu=='resurssit') echo 'class="active"';?>><a href="index.php?sivu=resurssit">Resurssit</a></li>
        </ul>
        </div>
        <ul class="nav navbar-nav navbar-right">
            <li <?php if($sivu=='oma') echo 'class="active"';?>><a href="index.php?sivu=oma">Omat tiedot</a></li>
            <li <?php if($sivu=='logout') echo 'class="active"';?>><a href="index.php?sivu=logout">Kirjaudu ulos
            </a></li>
        </ul>
  </div>
</nav>

	<div class="container">
		<?php
		//tutkitaan, mitä sivua näytetään tässä osassa
		if($sivu=='') {
            echo '<div class="jumbotron">';
			echo '<h3>Olet Admin tilassa</h3><p>';
            echo'<h5><p>Ylläpitäjä-sivulla näet ylläpitäjät ja pystyt tarvittaessa lisäämään ylläpitäjän.<p>';
            echo 'Varaukset-sivulla näet kaikki varaukset ja pystyt muokkamaan niitä.<p>';
            echo'Muut-Käyttäjä-sivulla näet kaikki rekisteröityneet käyttäjät jotka ei ole ylläpitäjiä.<p>';
            echo'Omat tiedot-sivulla voit halutessasi vaihtaa oman etunimen, sukunimen, sähköpostin tai salasanan.<p></h5>';
            echo'</div>';
		}	
		else if($sivu=='adminit') include('adminit.php');
		else if($sivu=='varaukset') include('varaukset.php');
		else if($sivu=='kayttajat') include('kayttajat.php');
        else if($sivu=='oma') include('oma.php');
		else if($sivu=='users') include('users.php');
		else if($sivu=='uusiAdmin') include('uusiAdmin.php');
		else if($sivu=='asiakas') include('asiakas.php');
        else if($sivu=='logout') include('logout.php');
        else if($sivu=='muokkaaVaraus') include('muokkaaVaraus.php');
        else if($sivu=='resurssit') include('resurssit.php');
        else if($sivu=='uusiResurssi') include('uusiResurssi.php');
        else if($sivu=='poistaResurssi') include('poistaResurssi.php');
        else if($sivu=='teeVaraus')include('teeVaraus.php');
		?>
        <p>	
			Kirjautunut:
        <p>
            <?php echo $_SESSION['nimi']?>
        <p>
			Kello:<?php echo $_SESSION['aika']?>
		</p>
	
	</div>
	</body>
</html>