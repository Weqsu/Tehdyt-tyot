<?php
/*
	file:	Lopputyö/src/admin/poistaResurssi.php
	desc:	Poistetaan resurssi admin-sivulla resurssiID:n avulla
	date:	18.05.2020
*/ 
    echo'<div class="col-sm-6">';
        echo' <h3>Poista resurssi</h3>';
                echo' <form action="poistaResurssi2.php" method="get">';
                    
			         echo'<select name="resurssiID" class="form-control" required>';
                    
                        echo'<option value="">-Valitse resurssi-</option>';
    
				        include('dbConnect.php');
				        $sql="SELECT resurssiID, nimi FROM resurssi ORDER BY nimi";
				        $tulos=$conn->query($sql);
				        if($tulos->num_rows > 0){
                            while($rivi=$tulos->fetch_assoc()){
					       echo '<option value="'.$rivi['resurssiID'].'">'.$rivi['nimi'].'</option>';
				 }
				}	
			         echo'</select>';

                echo'<button type="submit" class="btn btn-primary btn-block">Poista Resurssi</button>';
            echo'</form>';
    echo'</div>';

?>