<?php
/*
	file:	Lopputyö/src/rek.php
	desc:	Rekisteröitymislomake -> lähetetään talletaRekisterointi.phplle
    date:	11.05.2020
*/
?>

<form class="form-signin" action="talletaResurssi.php" method="post" >
  <h2 class="form-signin-heading">Uusi Resurssi</h2>
    <div class="form-group-sm">
      <label for="nimi"><b>Resurssin Nimi</b></label>
    <input type="text" class="form-control" name="nimi" id="nimi" placeholder="resurssin nimi" required>
    </div>
    
    <div class="form-group-sm">
    <label for="kuvaus"><b>Kuvaus</b></label>
    <input type="text" class="form-control" name="kuvaus" id="kuvaus" placeholder="kuvaus" required>
    </div>
    
    <div class="form-group-sm">  
    <label for="paikka"><b>Paikka</b></label>
    <input type="text" class="form-control" name="paikka" id="paikka" placeholder="paikka" required>
    </div>
        
    <div class="form-group-sm"> 
    <label for="huomautus"><b>Huomautus</b></label>
    <input type="text" class="form-control" name="huomautus" id="huomautus" placeholder="huomautus" required>  
    </div>
        
   <p></p>
    <button type="submit" class="btn btn-lg btn-primary">Talleta resurssi!</button>
</form>
