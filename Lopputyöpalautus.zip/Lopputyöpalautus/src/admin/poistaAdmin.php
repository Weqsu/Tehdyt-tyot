<?php
/*
	file:	opputyö/src/admin/poistaAdmnin.php
	desc:	Poistaa valitun käyttäjän tietokannasta
	date:	18.05.2020
*/
$adminID=$_GET['adminID'];
include('dbConnect.php');
$sql="DELETE FROM admin WHERE adminID=$adminID";
if($conn->query($sql) === TRUE) {
	//jos DELETE-lause onnistui, tieto päivittyi tietokantaan
	$conn->close();
	header('location:index.php?sivu=adminit&virhe=false&viesti=Käyttäjän poisto onnistui');
}else{
	$conn->close();
	header('location:index.php?sivu=adminit&virhe=true&viesti=Päivitys ei nyt onnistu! Yritä uudelleen.');
}
?>