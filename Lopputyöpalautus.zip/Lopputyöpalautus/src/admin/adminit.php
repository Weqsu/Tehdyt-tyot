<?php
/*
	file:	Lopputyö/src/admin/adminit.php
	desc:	Näyttää ylläpitäjälistan. Admin-roolissa olevat voivat lisätä/muokata tietoja
	date:	15.05.2020
*/
include('dbConnect.php');
//haetaan lista
$sql="SELECT * FROM admin ORDER BY sukunimi, etunimi";
$tulos=$conn->query($sql);
?>
<h3>Ajanvarausjärjestelmän Ylläpitäjät</h3>
<?php
echo '<p><a class="btn btn-primary" href="index.php?sivu=uusiAdmin">Lisää uusi ylläpitäjä</a></p>';
?>
<table class="table tbl-striped">
	<tr><th>AdminID</th><th>Nimi</th><th>Email</th><th>Poista Admin</th></tr>
	<?php
	while($rivi=$tulos->fetch_assoc()){
		echo '<tr>';
		echo '<td>'.$rivi['adminID'].'</td>';
        echo '<td>'.$rivi['sukunimi'].' '.$rivi['etunimi'].'</td>';
		echo '<td>'.$rivi['email'].'</td>';
        echo '<td><a class="btn btn-primary" href="poistaAdmin.php?adminID='.$rivi['adminID'].'">Poista</a></td>';
		echo'</tr>';
        
    }
	$conn->close();
    echo'</table>';
	?>