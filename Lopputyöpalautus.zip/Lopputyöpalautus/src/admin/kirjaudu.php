<?php
/*
	file:	admin/kirjaudu.php
	desc:	Kirjautumislomake
	date:	2.5.2018
	auth:	Yrjö K
*/
?>
<!DOCTYPE html>
<html>
<head>
 <title>Tilojen varaaminen</title>
 <meta charset="utf-8"> <!-- Luodaan bootsrap linkit + css linkit-->
 <meta name="viewport" content="width=device-width, initial-scale=1">   
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
 <link href="../css/style.css" rel="stylesheet">
</head>
	<body>
<div class="col-sm-4">
<form class="form-signin" action="login.php" method="post">
	<h2 class="form-signin-heading">Kirjaudu</h2>
  <div class="form-group">
    <label  for="email">Sähköpostiosoite:</label>
    <input type="email" class="form-control" name="email" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Salasana:</label>
    <input type="password" class="form-control" name="salasana" id="salasana">
  </div>
  <button type="submit" class="btn btn-lg btn-primary">Kirjaudu</button>
<p></p>
    
</form>
    </div>
	</body>
</html>