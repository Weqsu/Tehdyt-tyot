<?php
/*
	file:	Lopputyö/src/admin/kryptaasalasana.php
	desc:	Päivittää UserID 1:n salasana kryptatuksi - Testausta varten vain ensimmäiselle ylläpitäjälle tietokannassa
*/
include('dbConnect.php');
$salasana=password_hash('salasana',PASSWORD_DEFAULT);
$sql="UPDATE admin SET salasana='$salasana' WHERE adminID=1";
$conn->query($sql);
?>