<?php
/*
	file:	Lopputyö/src/admin/kayttajat.php
	desc:	Haetaan asiakas esim salasana generointia varten
	date:	16.05.2020
*/
include('dbConnect.php');
//haetaan lista
$sql="SELECT * FROM kayttajat ORDER BY sukunimi, etunimi";
$tulos=$conn->query($sql);
?>
<h4>Rekisteröityneet Käyttäjät</h4>
<p></p>
<table class="table table-striped">
	<tr>
		<th>Email</th><th>Nimi</th><th>Puhelin</th><th>Kaupunki</th><th>Katuosoite</th><th>Postinumero</th><th>Poista Käyttäjä</th>
	</tr>
    
	<?php
		while($rivi=$tulos->fetch_assoc()){
			echo '<tr>';
			echo '<td>'.$rivi['email'].'</td>';
			echo '<td>'.$rivi['etunimi'].' '.$rivi['sukunimi'].'</td>';
			echo '<td>'.$rivi['puhelin'].'</td>';
            echo '<td>'.$rivi['kaupunki'].'</td>';
            echo '<td>'.$rivi['katuosoite'].'</td>';
            echo '<td>'.$rivi['postinumero'].'</td>';
            echo '<td><a class="btn btn-primary" href="poistaKayttaja.php?jasenID='.$rivi['jasenID'].'">Poista</a></td>';
			echo '</tr>';
		}
		$conn->close();
	
	?>
</table>