<?php
/*
	file:	lisaaAdmin.php
	desc:	Tallentaa uuden user-taulun rivin. Generoi salasanan. Lähettäisi sähköpostilla email-osoitteeseen salasanan
			jos palvelimella email-lähetys mahdollista (ilman konfigurointia ei XAMPPissa)
	date:	14.5.2020
	auth:	Yrjö K
*/
if(empty($_POST)) header('location:index.php?sivu=resurssit');
$virhe=false;
$viesti='';
if(!empty($_POST['nimi'])) $nimi=$_POST['nimi']; else $virhe=true;
if(!empty($_POST['kuvaus'])) $kuvaus=$_POST['kuvaus']; else $virhe=true;
if(!empty($_POST['paikka'])) $paikka=$_POST['paikka']; else $virhe=true;
if(!empty($_POST['huomautus'])) $huomautus=$_POST['huomautus']; else $virhe=true;
    
include('dbConnect.php');
//tarkistetaan, että sama email ei jo ole tietokannassa
$sql="SELECT nimi FROM resurssi WHERE nimi='$nimi'";
$tulos=$conn->query($sql);
if($tulos->num_rows > 0) $virhe=true;
if(!$virhe){
	
	//talletus tietokantaan ja sähköpostia käyttäjälle
	$salasana=password_hash($randomString,PASSWORD_DEFAULT);
	$sql="INSERT INTO resurssi(nimi,kuvaus,paikka,huomautus) VALUES('$nimi','$kuvaus','$paikka','$huomautus')";
	if($conn->query($sql) === TRUE) {
		//jos INSERT-lause onnistui, tieto päivittyi tietokantaan
		$conn->close();
        header('location:index.php?sivu=resurssit&viesti=Resurssin lisäys onnistui!');
	}
}else header('location:index.php?sivu=resurssit&virhe=true');

?>