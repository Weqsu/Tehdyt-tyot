<?php
/*
	file:	Lopputyö/src/admin/uusiAdmin.php
	desc:	Uuden ylläpitäjän lisäyslomake
	date:	16.05.2020
*/
?>
<form class="form-signin" action="lisaaAdmin.php" method="post">
	<h2 class="form-signin-heading">Lisää ylläpitäjä</h2>
  <div class="form-group-sm">
    <label  for="email">Sähköpostiosoite:</label>
    <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
  </div>
  <div class="form-group-sm">
    <label  for="etunimi">Etunimi:</label>
    <input type="text" class="form-control" name="etunimi" id="etunimi" placeholder="Etunimi" required>
  </div>
  <div class="form-group-sm">
    <label  for="sukunimi">Sukunimi:</label>
    <input type="text" class="form-control" name="sukunimi" id="sukunimi" placeholder="Sukunimi" required>
  </div>
  <div class="form-group-sm">
    <label for="psw">Salasana</label>
    <input type="password" class="form-control" name="salasana" placeholder="Salasana" id="salasana" required>
  </div>
        
  <div class="form-group-sm">
    <label for="psw-repeat">Toista Salasana</label>
    <input type="password" class="form-control" name="salasana1" placeholder="Salasana uudelleen" id="salasana1" required>
  </div>
<p></p>
  <button type="submit" class="btn btn-lg btn-primary">Talleta</button>
</form>