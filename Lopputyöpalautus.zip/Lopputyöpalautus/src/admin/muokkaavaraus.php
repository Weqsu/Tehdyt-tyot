<?php
/*
	file:	Lopputyö/src/admin/muokkaavaraus.php
	desc:	
	date:	18.05.2020
*/ 
    echo'<div class="col-sm-6">';
        echo' <h3>Poista varaus</h3>';
echo'<h6>Varauksen nimi, Varaajan email, Varauksen Lopetusaika</h6>';
                echo' <form action="poistaVaraus.php" method="get">';
                    echo'<div class="form-group">';
			         echo'<select name="varausID" class="form-control" required>';
                    
                echo'<option value="">-Valitse resurssi-</option>';
    
				include('dbConnect.php');
				$sql="SELECT varausID, nimi, email, lopetusAika FROM resurssi INNER JOIN varaus 
                ON resurssi.resurssiID=varaus.resurssiID INNER JOIN kayttajat 
                ON varaus.jasenID=kayttajat.jasenID WHERE now() < lopetusAika";
				$tulos=$conn->query($sql);
				if($tulos->num_rows > 0){
				 while($rivi=$tulos->fetch_assoc()){
					 echo '<option value="'.$rivi['varausID'].'">'.$rivi['nimi'].' '.$rivi['email'].' '.$rivi['lopetusAika'].'</option>';
				 }
				}	
			echo'</select>';
    
    echo'<button type="submit" class="btn btn-primary btn-block">Poista Varaus</button>';
    echo'</form>';
    echo'</div>';

?>