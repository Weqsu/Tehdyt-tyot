<?php
/*
	file:	Lopputyö/src/admin/logout.php
	desc:	Hävittää session-tiedot, ohjaa julkiselle sivulle
	date:	16.05.2020
*/
session_start();
session_destroy();
header('location:../');
?>