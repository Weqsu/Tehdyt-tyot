<?php
/*
	file:	Lopputyö/src/admin/poistaAdmnin.php
	desc:	Poistaa valitun käyttäjän tietokannasta
	date:	18.05.2020
*/
$jasenID=$_GET['jasenID'];
include('dbConnect.php');
$sql="DELETE FROM kayttajat WHERE jasenID=$jasenID";
if($conn->query($sql) === TRUE) {
	//jos DELETE-lause onnistui, tieto päivittyi tietokantaan
	$conn->close();
	header('location:index.php?sivu=kayttajat&virhe=false&viesti=Käyttäjän poisto onnistui');
}else{
	$conn->close();
	header('location:index.php?sivu=kayttajat&virhe=true&viesti=Päivitys ei nyt onnistu! Yritä uudelleen.');
}
?>