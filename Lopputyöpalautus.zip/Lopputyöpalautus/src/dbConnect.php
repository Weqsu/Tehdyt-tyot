<?php
/*
	file:	Lopputyö/src/dbConnect.php
	desc:	Luo tietokantayhteyden MySQL-palvelimelle lopputyo-tietokantaan
	date:	11.05.2020
*/
$palvelin='localhost';
$tietokanta='lopputyo';
$dbtunnus='lopputyo';
$dbsalasana='lopputyo';

//mysqli-objektilla yhteys
$conn=new mysqli($palvelin,$dbtunnus,$dbsalasana,$tietokanta);
if($conn->connect_error){
	die('Tietokantayhteys ei onnistu.'.$conn->connect_error);
}
//ääkköset käyttöön tietokannan käsittelyssä
mysqli_set_charset($conn,"utf8");
?>