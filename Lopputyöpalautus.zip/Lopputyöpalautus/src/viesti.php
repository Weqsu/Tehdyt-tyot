<?php
/*
	file:   Lopputyö/src/viesti.php
	desc:	Näyttää esimerkiksi viestit rekisteröityessä/virheestä/kirjautumisesta 
	date:	11.05.2020
*/
$viesti=$_GET['viesti'];
$virhe=$_GET['virhe'];
if($virhe=='true'){
	echo '<p class="alert alert-danger">'.$viesti.'</p>';
	echo '<p><button id="goback" class="btn bnt-sm btn-primary">Takaisin</button></p>';
}else{
	echo '<p class="alert alert-dark">'.$viesti.'</p>';
}
?>