<?php
/*
	file: Lopputyö/src/talletaVaraus.php
	Desc: Talletetaan varaus tietokantaan
    date: 13.05.2020
*/
$resurssi=$_POST['resurssi'];
//poimitaan lomakkeelta tulevat pvm:t ja kellonajat erikseen-> alempana yhdistetään MySQL:ää varten yhdeksi arvoksi
$alkupvm=$_POST['alkupvm'];
$alkuklo=$_POST['alkuklo'];
$loppupvm=$_POST['loppupvm'];
$loppuklo=$_POST['loppuklo'];
//muutetaan varausajat sopiviksi MySQL:ää varten
$alkuaika=$alkupvm.' '.$alkuklo;
$loppuaika=$loppupvm.' '.$loppuklo;

	include('dbConnect.php');
	//tarkistetaan, että varauksia ei tehdä päällekkäin!
	$sql="SELECT varausID FROM varaus WHERE (('$alkuaika' BETWEEN varausAika AND lopetusAika) ";
	$sql.=" OR ('$loppuaika' BETWEEN varausAika AND lopetusAika) ";
	$sql.=" OR (varausAika AND lopetusAika BETWEEN '$alkuaika' AND  '$loppuaika'))";
	$sql.=" AND resurssiID=$resurssi";
	$tulos=$conn->query($sql);
	if($tulos->num_rows > 0) 
        header('location:index.php?sivu=viesti&viesti=Päällekkäinen varaus!&virhe=true');
	else{
        //talletetaan varaus olemassaolevan käyttäjän id:n perusteella
        session_start();
        $jasenID=$_SESSION['asiakasID'];
		$sql="INSERT INTO varaus(jasenID,resurssiID,varausAika,lopetusAika) VALUES ($jasenID,$resurssi,'$alkuaika','$loppuaika')";
		if($conn->query($sql)===TRUE){
			$conn->close();
			header('location:index.php?sivu=viesti&viesti=Varaus Tallennettu!&virhe=false'); //onnistunut varaus, takaisin lomakkeelle
		}else echo'<p>Varausta ei voitu tallentaa. Kokeile uudestaan!</p><p><a href="index.php?sivu=varaus">Alkuun</a></p>';
			$conn->close();
    }
    
?>
