<?php
/*
    file:   Lopputyö/src/omatVaraukset.php
    desc:   Näyttää listan henkilöistä, joilla on aktiivisia varauksia
    date:	16.05.2020
*/
include('dbConnect.php');
$sql="SELECT DISTINCT kayttajat.jasenID, email, sukunimi, etunimi, katuosoite, postinumero, kaupunki, puhelin FROM kayttajat 
        INNER JOIN varaus
        ON kayttajat.jasenID=varaus.jasenID
        WHERE now() < lopetusAika
        ORDER BY sukunimi,etunimi";
session_start();
$tulos=$conn->query($sql);
if($tulos->num_rows > 0){
    while($rivi=$tulos->fetch_assoc()){
        header('location:index.php?sivu=varaus&jasenID='.$_SESSION['asiakasID']);
       
    }
}else echo '<p class="alert alert-danger">Ei löytynyt yhtään varausta</p>';
?>