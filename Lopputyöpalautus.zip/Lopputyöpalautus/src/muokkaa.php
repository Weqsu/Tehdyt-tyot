<?php
/*
	file:	Lopputyö/src/muokkaa.php
	desc:	Näyttää käyttäjän tietojen päivityslomakkeen
	date:	16.05.2020
*/
if(!empty($_GET['virhe'])) $virhe=$_GET['virhe'];else $virhe=false;
if(!empty($_GET['viesti'])) $viesti=$_GET['viesti'];else $viesti='';
include('dbConnect.php');
$sql="SELECT * FROM kayttajat WHERE jasenID=".$_SESSION['asiakasID'];
$tulos=$conn->query($sql);
if($tulos->num_rows > 0){
	$rivi=$tulos->fetch_assoc();
?>
<div class="row">

 <div class="col-sm-6">
  <form class="form-signin" action="paivitaJasen.php" method="post">
	<h2 class="form-signin-heading">Ylläpito - Päivitä tietosi</h2>
  <div class="form-group">
    <label  for="email">Sähköpostiosoite:</label>
    <input type="email" class="form-control" name="email" id="email" value="<?php echo $rivi['email']?>" placeholder="email" required>
  </div>
  <div class="form-group">
    <label  for="etunimi">Etunimi:</label>
    <input type="text" class="form-control" name="etunimi" id="etunimi" value="<?php echo $rivi['etunimi']?>" placeholder="etunimi" required>
  </div>
  <div class="form-group">
    <label  for="sukunimi">Sukunimi:</label>
    <input type="text" class="form-control" name="sukunimi" id="sukunimi" value="<?php echo $rivi['sukunimi']?>" placeholder="sukunimi" required>
  </div>
      <div class="form-group">
    <label  for="puhelin">Puhelin:</label>
    <input type="text" class="form-control" name="puhelin" id="puhelin" value="<?php echo $rivi['puhelin']?>" placeholder="puhelin" required>
  </div>
      <div class="form-group">
    <label  for="kaupunki">Kaupunki:</label>
    <input type="text" class="form-control" name="kaupunki" id="kaupunki" value="<?php echo $rivi['kaupunki']?>" placeholder="kaupunki" required>
  </div>
      <div class="form-group">
    <label  for="katuosoite">Katuosoite:</label>
    <input type="text" class="form-control" name="katuosoite" id="katuosoite" value="<?php echo $rivi['katuosoite']?>" placeholder="katuosoite" required>
  </div>
      <div class="form-group">
    <label  for="postinumero">Postinumero:</label>
    <input type="text" class="form-control" name="postinumero" id="postinumero" value="<?php echo $rivi['postinumero']?>" placeholder="postinumero" required>
  </div>
  <button type="submit" class="btn btn-lg btn-primary">Päivitä tiedot</button>
  </form>
     </div>
    
<?php
	if($virhe=='false') echo '<p class="alert alert-success">'.$viesti.'</p>';
	else if($viesti!='') echo '<p class="alert alert-danger">'.$viesti.'</p>';
}else echo '<p class="alert alert-danger">Ei löydy ko käyttäjää</p>';
$conn->close();
?>
 
 <div class="col-sm-6">
	<form class="form-signin" action="paivitaSalasana.php" method="post">
	<h2 class="form-signin-heading">Ylläpito - Päivitä salasanasi</h2>
	<div class="form-group">
    <label for="salasana">Nykyinen salasana:</label>
    <input type="password" class="form-control" name="salasana" id="salasana" required>
  </div>
  <div class="form-group">
    <label for="salasana1">Uusi salasana:</label>
    <input type="password" class="form-control" name="salasana1" id="salasana1" required>
  </div>
  <div class="form-group">
    <label for="salasana2">Uusi salasana vahvistus:</label>
    <input type="password" class="form-control" name="salasana2" id="salasana2" required>
  </div>
  <button type="submit" class="btn btn-lg btn-primary">Vaihda salasana</button>
     </form>
</div></div>