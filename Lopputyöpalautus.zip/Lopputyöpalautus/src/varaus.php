<?php
/*
	file:	Lopputyö/src/varaus.php
	desc:	Varaus.php-sivulle pääsee jos käyttäjä on rekisteröitynyt ja kirjautunut sisään
	date:	13.05.2020
*/
if(!isset($_SESSION['asiakas'])){
    echo '<p class="alert alert-dark">Varauksen tekeminen vaatii <a class="alert-dark" href="index.php?sivu=omatili">kirjautumisen</a>.</p>';
}else{
       

echo'<!DOCTYPE html>';
echo'<html>';
echo'<head>';
 echo'<title>Tilojen varaaminen</title>';
 echo'<meta charset="utf-8">';
 echo'<meta name="viewport" content="width=device-width, initial-scale=1">'; 
 echo'<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">';
 echo'<link href="css/style.css" rel="stylesheet">';
echo'</head>';
    
echo'<div class="row list-group-item-dark">';
    
    echo'<div class="col-sm">';
        echo' <h3>Tee varaus</h3>';
                echo' <form action="talletaVaraus.php" method="post">';
                    echo'<div class="form-group">';
			         echo'<label for="resurssi">Valitse varattava resurssi:</label>';
			         echo'<select name="resurssi" class="form-control" required>';
                    
                echo'<option value="">-Valitse resurssi-</option>';
    
				include('dbConnect.php');
				$sql="SELECT resurssiID, nimi FROM resurssi ORDER BY nimi";
				$tulos=$conn->query($sql);
				if($tulos->num_rows > 0){
				 while($rivi=$tulos->fetch_assoc()){
					 echo '<option value="'.$rivi['resurssiID'].'">'.$rivi['nimi'].'</option>';
				 }
				}	
			echo'</select>';
		echo'</div>';
  
    
    
//Varauspäivä + aika / Loppupvm + aika
    echo'<div class="col-sm">';
		echo'<div class="form-group">';
            echo'<label for="alkupvm">Varaus Päivä:</label>';
			echo'<input type="date" class="form-control" id="alkupvm" placeholder="Päivä" name="alkupvm" required>';
        echo'</div>';
		echo'<div class="form-group">';
            echo'<label for="alkuklo">Varaus Aika:</label>';
			echo'<input type="time" class="form-control" id="alkuklo" placeholder="Kello" name="alkuklo" required>';
        echo'</div>';
		echo'<div class="form-group">';
            echo'<label for="loppupvm">Loppupvm:</label>';
			echo'<input type="date" class="form-control" id="loppupvm" placeholder="Päivä" name="loppupvm" required>';
        echo'</div>';
		echo'<div class="form-group">';
            echo'<label for="loppuklo">Loppuklo:</label>';
			echo'<input type="time" class="form-control" id="loppuklo" placeholder="Kello" name="loppuklo" required>';
       echo' </div>';
    echo'</div>';
    echo'<button type="submit" class="btn btn-primary btn-block">Talleta Varaus</button>';
    echo'</form>';
    echo'</div>';


//Nyt tällä hetkellä vapaana olevat varaukset
 echo'<div class="col-sm-4">';
  echo'<h3>Tänään vapaana</h3>';
	$sql="SELECT nimi,resurssi.resurssiID FROM resurssi 
			WHERE resurssiID NOT IN
			( SELECT resurssiID FROM varaus WHERE (CURRENT_DATE() 
			BETWEEN varausAika AND lopetusAika) 
			OR (CURRENT_DATE = date(varausAika)) 
			OR (CURRENT_DATE = date(lopetusAika)))";
	$tulos=$conn->query($sql);
	if($tulos->num_rows > 0){
		while($rivi=$tulos->fetch_assoc()){
			echo '<li class="list-group-item"><small>';
			echo $rivi['nimi'].'</small></li>';
		}
	}
     echo'</div>';
    
    
//Jos varauksia vapautumassa ne näkyvät tässä
    echo'<div class="col-sm-4">';
  echo'<h3>Tänään vapautuu</h3>';
	$sql="SELECT nimi,resurssi.resurssiID FROM resurssi 
			WHERE resurssiID IN
			( SELECT resurssiID FROM varaus WHERE (CURRENT_DATE = date(lopetusAika)))";
	$tulos=$conn->query($sql);
	if($tulos->num_rows > 0){
		while($rivi=$tulos->fetch_assoc()){
			echo '<li class="list-group-item"><small>';
			echo $rivi['nimi'].'</small></li>';
		}
	}

 echo'</div>';
 echo'</div>';
echo '<p></p>';


//Aijemmat varaukset näkyvät tässä
$sql="SELECT varausID, varausAika,lopetusAika,sukunimi,etunimi,email, puhelin, nimi 
        FROM varaus 
        INNER JOIN kayttajat 
        ON varaus.jasenID=kayttajat.jasenID 
        INNER JOIN resurssi 
        ON varaus.resurssiID=resurssi.resurssiID 
        WHERE now() < lopetusAika ";
if(isset($_GET['resurssiID'])) $sql.=" AND resurssi.resurssiID=".$_GET['resurssiID'];
if(isset($_GET['jasenID'])) $sql.=" AND kayttajat.jasenID=".$_GET['jasenID'];
$sql.=" ORDER BY varausAika";
$tulos=$conn->query($sql);
if($tulos->num_rows > 0){
    //löytyi tietoa
    echo '<div class="row">';
    $laskuri=0;
    while($rivi=$tulos->fetch_assoc()){
        $alkuaika=date_create($rivi['varausAika']);  //muokataan päivämäärän esitysmuotoa ja sen vuoksi
        $loppuaika=date_create($rivi['lopetusAika']);//alku- ja loppuaika poimitaan muuttujille tietokantariviltä
        echo '<div class="col-sm-6">';
        echo '<div class="card"><div class="card-header text-center"><p>Varaus ajalle:<br><b>';
		//tulostetaan alku- ja loppuaika erikseen eli pvm muotoiltuna ja klo muotoiltuna
        echo date_format($alkuaika,'d.m.Y').', klo '.date_format($alkuaika,'H:i').' - ';
        echo date_format($loppuaika,'d.m.Y').', klo '.date_format($loppuaika,'H:i').'</b></p></div>';
        echo '<div class="card-body bg-success text-center">'.$rivi['nimi'].'</div>';
        echo '<div class="card-footer text-center"><p>Varaaja:<br><b>'.$rivi['etunimi'].' '.$rivi['sukunimi'];
        echo '</b><br>'.$rivi['email'];
        echo '</p></div></div>';
        echo '</div>';
        $laskuri++;
        if($laskuri==2) echo '</div><p></p><div class="row">';
    }
    echo '</div>';
}else echo '<p class="alert alert-success">Ei löytynyt varauksia!</p>';
  echo'</ul>';
 echo'</div>';

}
?>