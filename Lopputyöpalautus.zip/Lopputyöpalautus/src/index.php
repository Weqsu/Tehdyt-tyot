<?php
/*
	file:	Lopputyö/src/index.php
	desc:	Sovelluksen etusivu PHP-versiona. Bootstrap Online store template W3schools
	date:	11.05.2020
*/
if(!empty($_GET['sivu'])) $sivu=$_GET['sivu'];else $sivu='';
session_start(); //Asiakkaan kirjautumisen muistamiseksi session päälle
?>
<!DOCTYPE html>
<html>
<head>
 <title>Tilojen varaaminen</title>
 <meta charset="utf-8"> <!-- Luodaan bootsrap linkit + css linkit-->
 <meta name="viewport" content="width=device-width, initial-scale=1">   
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
 <link href="css/style.css" rel="stylesheet">
 <link href="css/css.css" rel="stylesheet">
</head>
<body>
  <!--onload komento piti tehdä frontendissä mutta laitoin sen kommentiksi-->
  <!--<body onload="myFunction()">-->
  <!-- Luodaan navigointi palkki sivun ylälaitaan joka toimii kaikilla php-sivuilla-->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">    
    <div class="container-fluid">
        <div class="navbar-header">
  <!-- Luodaan LapinAmk:n logo navigointi palkkiin-->
      <a class="navbar-brand" href="index.php"><img src="images/uus1.png" class="img-responsive"></a>
        </div>
        
        <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
            <!--Etusivun linkit-->
        <li class=header <?php if($sivu=='') echo 'class="active"';?>><a href="index.php">Etusivu
        </a></li>
          
        <li <?php if($sivu=='rek') echo 'class="active"';?>><a href="index.php?sivu=rek">Rekisteröidy
        </a></li>
          
        <li <?php if($sivu=='info') echo 'class="active"';?>><a href="index.php?sivu=info">Info
        </a></li>
        <li <?php if($sivu=='varaus' OR $sivu=='talletaVaraus') echo 'class="active"';?>><a href="index.php?sivu=varaus">Varaus
        </a></li>
        </ul>
        </div>
        
        <ul class="nav navbar-nav navbar-right">
            
            <li <?php if($sivu=='omatili' OR $sivu=='omatVaraukset') echo 'class="active"';?>><a href="index.php?sivu=omatili">Oma tili
            </a></li>
        </ul>
    
  </div>
</nav>

    
<div class="container"> 
  <?php
  //Tutkitaan mitä sivua näytetään tässä osassa
  if($sivu=='') include('etusivu.php');	//näytetään etusivu.php
  else if($sivu=='kirjaudu') include('kirjaudu.php');//kirjautumis sivulle
  else if($sivu=='rek') include('rek.php');	//rekisteröitymis-lomakkeelle
  else if($sivu=='omatili') include('kirjaudu.php');//kirjautumis sivulle
  else if($sivu=='info') include('info.php');//info-sivu mistä löytyy yhteystietoja
  
  else if($sivu=='viesti') include('viesti.php'); //viesti-sivulta virhe + onnistumis ilmoitukset
  else if($sivu=='varaus') include('varaus.php'); //varaus-sivulle'
  else if($sivu=='talletaVaraus') include ('talletaVaraus.php');
  else if($sivu=='omatVarakuset') include ('omatVaraukset');
  else if($sivu=='muokkaa') include ('muokkaa.php');
  else{
	  echo '<p><button id="goback" class="btn bnt-sm btn-primary">Takaisin</button></p>';
	  echo '<p class="alert alert-danger">Sivua ei löytynyt</p>';
  }
  ?> 
        
        

    </div>
	<!-- Alapalkki bootstrapin mukaan, seuraa kaikilla sivuilla-->
<footer class="container-fluid text-center">
<span class="badge badge-default"><img alt="LapinAMKLogo" width="80px" src="images/logo.jpg">Ville Soramäki, ville.soramaki@edu.lapinamk.fi, 044 514 4554, Kaarnaraitti 3 A 4 90940 Jääli Oulu</span>
</footer>
  <!-- javascripti linkit-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/omajs.js"></script>
  </body>
</html>