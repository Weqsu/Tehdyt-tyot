<?php
/*
	file:	Lopputyö/src/rek.php
	desc:	Rekisteröitymislomake -> lähetetään talletaRekisterointi.phplle
    date:	11.05.2020
*/
if(!empty($_GET['virhe'])) $virhe=$_GET['virhe'];else $virhe=false;
if($virhe) echo '<p class="alert alert-danger">Virhe rekisteröintitiedoissa</p>';
?>
<div class="col-sm-8 list-group-item-dark">
<form class="form-signin" action="talletaRekisterointi.php" method="post" >
  <h2 class="form-signin-heading">Rekisteröidy täyttämällä kaikki kentät!</h2>
    <div class="form-group-sm">
      <label for="email"><b>Sähköposti</b></label>
    <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
    </div>
    
    <div class="form-group-sm">
    <label for="etunimi"><b>Etunimi</b></label>
    <input type="text" class="form-control" name="etunimi" id="etunimi" placeholder="Etunimi" required>
    </div>
    
    <div class="form-group-sm">  
    <label for="sukunimi"><b>Sukunimi</b></label>
    <input type="text" class="form-control" name="sukunimi" id="sukunimi" placeholder="Sukunimi" required>
    </div>
        
    <div class="form-group-sm"> 
    <label for="puhelin"><b>Puhelin</b></label>
    <input type="text" class="form-control" name="puhelin" id="puhelin" placeholder="Puh.Numero" required>  
    </div>
    
    <div class="form-group-sm"> 
    <label for="kapunki"><b>Kaupunki</b></label>
    <input type="text" class="form-control" name="kaupunki" id="kaupunki" placeholder="Kaupunki" required>  
    </div>
    
    <div class="form-group-sm"> 
    <label for="katuosoite"><b>Katuosoite</b></label>
    <input type="text" class="form-control" name="katuosoite" id="katuosoite" placeholder="Katuosoite" required>  
    </div>
    
    <div class="form-group-sm"> 
    <label for="postinumero"><b>Postinumero</b></label>
    <input type="text" class="form-control" name="postinumero" id="postinumero" placeholder="Postinumero" required>  
    </div>
        
    <div class="form-group-sm">
    <label for="psw"><b>Salasana</b></label>
    <input type="password" class="form-control" name="salasana" placeholder="Salasana" id="salasana" required>
    </div>
        
    <div class="form-group-sm">
    <label for="psw-repeat"><b>Toista Salasana</b></label>
    <input type="password" class="form-control" name="salasana1" placeholder="Salasana uudelleen" id="salasana1" required>
    </div>
        
   <p></p>
    <button type="submit" class="btn btn-lg btn-primary">Rekisteröidy!</button>
    </div>
</form>
