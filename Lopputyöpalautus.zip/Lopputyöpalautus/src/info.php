<?php
/*
	file:	Lopputyö/src/info.php
	desc:   Näyttää LapinAMK:n infoja
	date:	11.05.2020
*/
?>   
	<div class="row">
		<div class="col-md-6">
			<h2 class="intro2">
				Yhteystiedot
			</h2>
			<p>Asiakaspalvelu </p>
            <p>Puh. 044 123 4567</p>
            <p>Email. ASPA@Lapinamk.fi</p>
            <p>Minerva, Kauppakatu 58 Tornio</p>
		</div>
		<div class="col-md-6">
			<h2 class="intro2">
				Lapin AMK Tornio
			</h2>
			<p>Minerva, Kauppakatu 58</p>
            <p>Kulttuuriala * Cultural & Media Arts</p>
			<p>Liiketalous ja tietojenkäsittely * Business & ICT </p>
            <p>eOppimispalvelut * eLearning Services</p>
            <p>Minervakirjasto * Minerva Library</p>
            <p>LiikeAkatemia</p>
        </div>
</div>
   