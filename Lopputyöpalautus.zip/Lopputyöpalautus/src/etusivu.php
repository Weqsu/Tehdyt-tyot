<?php
/*
	file:	Lopputyö/src/etusivu.php
	desc:	Tulostaa etusivu.php scriptin index.php aloitus-sivulle
	date:	11.05.2020
*/
?>
<div class="jumbotron">
        <img alt="LapinAMKText" class="lapinTxt" src="images/lapinamk1.jpg">

                
                
        
            <h2 class="intro2">
                Ajanvarausjärjestelmä</h2>
                <p id="demo"></p>
        

                <p>Tämän sivu on Lapin AMK:n Eye-tracking tilojen ajanvarausjärjestelmä.</p>
                <p>Rekisteröi käyttäjätilisi</p>
                <p>Kirjaudu sisään</p>
                <p>Varaa-aika itsellesi tai ryhmällesi!</p>
                <p></p>
                <p><a class="btn btn-primary btn-large" href="index.php?sivu=rek">Rekisteröidy tästä!</a></p>
    
</div>