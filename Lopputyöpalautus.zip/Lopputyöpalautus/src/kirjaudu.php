<?php
/*
	file:	Lopputyö/src/kirjaudu.php
	desc:	Näyttää asiakkaan kirjautumislomakkeen. Kirjautuneelle näyttää omat tiedot ja salasanan vaihtomahdollisuuden.
	date:	13.05.2020
*/
if(!isset($_SESSION['asiakas'])){
?>
<form class="form-signin" action="login.php" method="post">
	<h2 class="form-signin-heading">Kirjaudu</h2>
  <div class="form-group">
    <label  for="email">Sähköpostiosoite:</label>
    <input type="email" class="form-control" name="email" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Salasana:</label>
    <input type="password" class="form-control" name="salasana" id="salasana">
  </div>
  <button type="submit" class="btn btn-lg btn-primary">Kirjaudu</button>
<p></p>
<p>Jos et ole vielä rekisteröitynyt, tee se heti <a href="index.php?sivu=rek">tästä.</a></p>
</form>
<?php
}else{
	//Kirjauneen käyttäjän tiedot
	echo '<div class="container">';
	echo '<div class="list-group">';
    
	echo '<h3>Käyttäjä: '.$_SESSION['asiakas'].'</h3>';
    
	echo '<table class="table-striped">';
	include('dbConnect.php');
    
    //Asiakkaan tiedot
	$sql="SELECT email, etunimi, sukunimi, puhelin, kaupunki, katuosoite, postinumero FROM kayttajat WHERE jasenID=".$_SESSION['asiakasID'];
	$tulos=$conn->query($sql);
	if($tulos->num_rows > 0){
		$rivi=$tulos->fetch_assoc();
		echo '<tr><td>Email: </td><td>'.$rivi['email'].'</td></tr>';
        echo '<tr><td><p></p></td></tr>';
		echo '<tr><td>Puhelin: </td><td>'.$rivi['puhelin'].'</td></tr>';
        echo '<tr><td><p></p></td></tr>';
        echo '<tr><td>Kaupunki: </td><td>'.$rivi['kaupunki'].'</td></tr>';
        echo '<tr><td><p></p></td></tr>';
        echo '<tr><td>Katuosoite: </td><td>'.$rivi['katuosoite'].'</td></tr>';
        echo '<tr><td><p></p></td></tr>';
        echo '<tr><td>Postinumero: </td><td>'.$rivi['postinumero'].'</td></tr>';
	}
	$conn->close();
    echo '</table>';
    
	echo '<ul class="list-inline">';
    //Muokkaus-linkit
    echo '<li><a href="index.php?sivu=muokkaa" class="list-group-item list-group-item-dark">Muokkaa käyttäjän tiedot</a></li>';
	echo '<li><a href="omatVaraukset.php?asiakasID='.$_SESSION['asiakasID'].'" class="list-group-item list-group-item-dark">Omat varaukset</a></li>';
	echo '<li><a href="logout.php" class="list-group-item list-group-item-dark">Kirjaudu ulos</a></li>';
	echo '</ul></div></div>';
}
?>
