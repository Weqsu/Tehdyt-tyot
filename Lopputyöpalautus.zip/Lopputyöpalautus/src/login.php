<?php
/*
    file:   Lopputyö/src/login.php
    desc:   Rekisteröitynyt asiakas kirjautuu käyttäjäksi. Tarkistetaan löytyykö emailin perusteella salasana. Salasana tietokannassa kryptattuna, joten tarkistus password_verify()-funktiolla.
    date:	13.05.2020
*/
if(!empty($_POST)){
    //Tultiin lomakkeelta, tarkistukset yms
    include('dbConnect.php'); 
    //real_escape_string-funktiolla poistetaan "väärien merkkien mahdollisuudet"
    $email=$conn->real_escape_string($_POST['email']);
    $salasana=$conn->real_escape_string($_POST['salasana']);
    $sql="SELECT jasenID,email,etunimi,sukunimi,puhelin,salasana FROM kayttajat WHERE email='$email'";
    $tulos=$conn->query($sql);
    if($tulos->num_rows > 0){
        //löytyi emailin perusteella tietoa, haetaan tiedot riville
        $rivi=$tulos->fetch_assoc();
        //Verrataan löytynyttä kryptattua salasanaa annettuun salasanaan
        //password_verify()-funktio tarkistaa ne kryptattuna
        if(password_verify($salasana,$rivi['salasana'])){
            //salasana täsmää->lisätään session-tietoihin asiakas
            session_start();
            $_SESSION['asiakasID']=$rivi['jasenID'];
            $_SESSION['asiakas']=$rivi['etunimi'].' '.$rivi['sukunimi'];
            header('location:index.php?sivu=viesti&viesti=Kirjautuminen onnistui!&virhe=false');
        }else header('location:index.php?sivu=omatili&virhe=salasana');
    }else header('location:index.php?sivu=omatili&virhe=email');
}else header('location:index.php?sivu=omatili');
?>