-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20.05.2020 klo 10:12
-- Palvelimen versio: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lopputyo`
--
CREATE DATABASE IF NOT EXISTS `lopputyo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lopputyo`;

-- --------------------------------------------------------

--
-- Rakenne taululle `admin`
--

CREATE TABLE `admin` (
  `adminID` int(11) NOT NULL,
  `etunimi` varchar(50) NOT NULL,
  `sukunimi` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `salasana` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vedos taulusta `admin`
--

INSERT INTO `admin` (`adminID`, `etunimi`, `sukunimi`, `email`, `salasana`) VALUES
(1, 'Ville', 'Soramäki', 'ville.soramaki@hotmail.com', '$2y$10$ESCIGS1PsHwz6UjnwJzPl.uUCFi6U/jHdAaF/qO8IDOMrFX5Wvh02'),
(17, 'Yrjö', 'Koskenniemi', 'yrjo.koskenniemi@lapinamk.fi', '$2y$10$.tw16zsD7nc..t0eMWRI8u/SYtVmObDmxbaGFVmtoCGzFOfCIk3z6'),
(18, 'Jaakko', 'Pesonen', 'jaakko.pesonen@edu.lapinamk.fi', '$2y$10$rkKuGmtn8KdYxbmNJMxyGe2ojCvxHDwle1cA.uEKuxt5z4Jukcl52');

-- --------------------------------------------------------

--
-- Rakenne taululle `kayttajat`
--

CREATE TABLE `kayttajat` (
  `jasenID` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `etunimi` varchar(20) NOT NULL,
  `sukunimi` varchar(20) NOT NULL,
  `puhelin` varchar(50) NOT NULL,
  `salasana` varchar(200) NOT NULL,
  `kaupunki` varchar(50) NOT NULL,
  `katuosoite` varchar(50) NOT NULL,
  `postinumero` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vedos taulusta `kayttajat`
--

INSERT INTO `kayttajat` (`jasenID`, `email`, `etunimi`, `sukunimi`, `puhelin`, `salasana`, `kaupunki`, `katuosoite`, `postinumero`) VALUES
(17, 'ville.soramaki@edu.lapinamk.fi', 'Ville', 'Soramäki', '0445144554', '$2y$10$zPPcRcQkmnLqs0UTHXp6O.KZMA4wUS1kl6BHJ82sKXJkSehumrFS2', '', '', ''),
(18, 'ville.soramaki@hotmail.com', 'Ville', 'Soramäki', '0445144554', '$2y$10$J7kABWQP7R3iRYPTBRd8Tey9FyT/XkluLtIVLk8AxdB8e4k1zPHG2', 'Oulu', 'Kaarnaraitti 3 A 4', '90940'),
(238, 'henri_soramaki@hotmail.com', 'Henri', 'Soramäki', '0408352835', '$2y$10$dnJ870WypFCF6sawLlHPFOStwXvDt0MJfSqFka8CZzT4itgGJVqRa', 'Oulu', 'Asemakatu 30 A 65', '90100'),
(239, 'Elinagumpler@gmail.com', 'Elina', 'Gumpler', '0440120502', '$2y$10$/QXX7yXE8MY2bMmn288Zy.8C6cko8yYw/MSBaJ5r/5Y8qwhmtu46y', 'Oulu', 'Kaarnaraitti 3 A 4', '90940'),
(240, 'yrjo.koskenniemi@lapinamk.fi', 'Yrjö', 'Koskenniemi', '0503109230', '$2y$10$.gBRFu1T4/xbUmqacva5Nub/s7t8R4EgtO4vs.hjq4JJC4vcutlRi', 'Tornio', 'Soratie 5', '95420');

-- --------------------------------------------------------

--
-- Rakenne taululle `resurssi`
--

CREATE TABLE `resurssi` (
  `resurssiID` int(11) NOT NULL,
  `nimi` varchar(50) NOT NULL,
  `kuvaus` varchar(50) NOT NULL,
  `paikka` varchar(50) NOT NULL,
  `huomautus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vedos taulusta `resurssi`
--

INSERT INTO `resurssi` (`resurssiID`, `nimi`, `kuvaus`, `paikka`, `huomautus`) VALUES
(1, 'VR-Lasit', 'Päähän laitettavat VR-lasit', 'laite', 'Mobiili ainostaan'),
(2, 'Eye-Lasit', 'Eye-tracking lasit', 'laite', 'Mukanaan liikutettava laite'),
(3, 'Eye-Tietokone', 'Eye-Tracking tietokone', 'tila 301', 'Alakerran luokka minervassa'),
(4, '3D-Maalaustila', '3D-Maalaustila', 'tila 301', 'test'),
(5, 'Studio', 'Studio', 'tila 301', 'test'),
(6, 'Neuvottelu-Huone', 'Neuvottelu-Huone', 'Neuvottelu-Huone', 'test'),
(7, 'ROTKO-kerhohuone', 'ROTKO-kerhohuone', 'ROTKO-kerhohuone', 'test'),
(8, 'Ruohonleikkuri', 'Ruohonleikkuri', 'Ulkovarasto', 'testi');

-- --------------------------------------------------------

--
-- Rakenne taululle `varaus`
--

CREATE TABLE `varaus` (
  `varausID` int(11) NOT NULL,
  `jasenID` int(11) NOT NULL,
  `resurssiID` int(11) NOT NULL,
  `varausAika` datetime NOT NULL,
  `lopetusAika` datetime NOT NULL,
  `huomautus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vedos taulusta `varaus`
--

INSERT INTO `varaus` (`varausID`, `jasenID`, `resurssiID`, `varausAika`, `lopetusAika`, `huomautus`) VALUES
(1, 17, 1, '2020-05-13 17:30:51', '2020-05-14 17:30:51', 'test'),
(14, 17, 2, '2020-05-13 22:30:00', '2020-05-13 23:00:00', ''),
(15, 17, 3, '2020-05-13 22:32:00', '2020-05-13 22:35:00', ''),
(16, 17, 2, '2020-05-12 15:00:00', '2020-05-12 16:00:00', ''),
(17, 18, 4, '2020-05-15 21:00:00', '2020-05-16 21:00:00', ''),
(18, 18, 2, '2020-05-15 23:00:00', '2020-05-16 08:00:00', ''),
(19, 18, 3, '2020-05-15 20:00:00', '2020-05-16 20:00:00', ''),
(20, 18, 1, '2020-05-15 20:03:00', '2020-05-15 20:10:00', ''),
(21, 17, 5, '2020-05-15 20:00:00', '2020-05-16 20:00:00', ''),
(22, 18, 4, '2020-05-18 09:00:00', '2020-05-18 15:00:00', ''),
(23, 17, 2, '2020-05-18 09:00:00', '2020-05-18 15:00:00', ''),
(25, 18, 7, '2020-05-18 09:00:00', '2020-05-18 20:00:00', ''),
(26, 18, 4, '2020-05-19 08:00:00', '2020-05-19 15:00:00', ''),
(27, 18, 5, '2020-05-19 08:00:00', '2020-05-20 08:00:00', ''),
(30, 18, 4, '2020-05-21 09:00:00', '2020-05-21 10:00:00', ''),
(31, 17, 1, '2020-05-21 10:01:00', '2020-05-21 15:00:00', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `kayttajat`
--
ALTER TABLE `kayttajat`
  ADD PRIMARY KEY (`jasenID`);

--
-- Indexes for table `resurssi`
--
ALTER TABLE `resurssi`
  ADD PRIMARY KEY (`resurssiID`);

--
-- Indexes for table `varaus`
--
ALTER TABLE `varaus`
  ADD PRIMARY KEY (`varausID`),
  ADD KEY `jasenID` (`jasenID`),
  ADD KEY `resurssiID` (`resurssiID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `kayttajat`
--
ALTER TABLE `kayttajat`
  MODIFY `jasenID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;

--
-- AUTO_INCREMENT for table `resurssi`
--
ALTER TABLE `resurssi`
  MODIFY `resurssiID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `varaus`
--
ALTER TABLE `varaus`
  MODIFY `varausID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Rajoitteet vedostauluille
--

--
-- Rajoitteet taululle `varaus`
--
ALTER TABLE `varaus`
  ADD CONSTRAINT `varaus_ibfk_1` FOREIGN KEY (`jasenID`) REFERENCES `kayttajat` (`jasenID`),
  ADD CONSTRAINT `varaus_ibfk_2` FOREIGN KEY (`resurssiID`) REFERENCES `resurssi` (`resurssiID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
